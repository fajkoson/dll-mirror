// The longer pid_tempname was used to distinguish from GNU's tempname header

///@brief Generates a unique pid temporary file
const char *pid_tempname (const char *prefix);